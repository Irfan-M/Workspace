function m = absolute1(x)

m=abs(x)
show_image(m);

end

