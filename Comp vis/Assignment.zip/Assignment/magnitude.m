function m = magnitude(x,y)

m= sqrt(x.^2 + y.^2);
show_image(m);

end

