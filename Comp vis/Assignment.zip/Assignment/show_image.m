function show_image(img)
% SHOW_IMAGE Image

colormap(gray);
imagesc(img);