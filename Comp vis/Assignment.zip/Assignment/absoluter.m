function m = absoluter(x,y)

m=abs(x)+abs(y);
show_image(m);

end

